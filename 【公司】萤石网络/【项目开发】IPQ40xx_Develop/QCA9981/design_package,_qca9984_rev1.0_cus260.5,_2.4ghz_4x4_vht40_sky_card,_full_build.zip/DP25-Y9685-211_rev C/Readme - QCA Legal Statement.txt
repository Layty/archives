Confidential and Proprietary � Qualcomm Atheros, Inc.

� 2015 Qualcomm Incorporated. All rights reserved.

NO PUBLIC DISCLOSURE PERMITTED: Please report postings of this document on public servers or websites to: DocCtrlAgent@qualcomm.com.

Not to be used, copied, reproduced, or modified in whole or in part, nor its contents revealed in any manner to others without the express written permission of Qualcomm Atheros, Inc.

Restricted Distribution: Not to be distributed to anyone who is not an employee of either Qualcomm Atheros, Inc. or its affiliated companies without the express approval of Qualcomm Configuration Management.

Qualcomm is a trademark of Qualcomm Incorporated, registered in the United States and other countries. All Qualcomm Incorporated trademarks are used with permission. Other product and brand names may be trademarks or registered trademarks of their respective owners.

This technical data may be subject to U.S. and international export, re-export, or transfer (�export�) laws. Diversion contrary to U.S. and international law is strictly prohibited.

Qualcomm Atheros, Inc. 
1700 Technology Drive 
San Jose, CA 95110 
U.S.A.