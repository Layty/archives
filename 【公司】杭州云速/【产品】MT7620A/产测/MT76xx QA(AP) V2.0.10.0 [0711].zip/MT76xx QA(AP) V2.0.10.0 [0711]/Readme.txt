
1. Make sure you have installed WinPcap.

2. In windows 7, the QA tool MUST run as an administrator.