#ifndef SOCKET_UTIL_H
#define SOCKET_UTIL_H

int set_noblock(int sClient);

int set_reused(int fd);

#endif
