/*
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License Version 2 as
** published by the Free Software Foundation.  You may not use, modify or
** distribute this program under any other version of the GNU General
** Public License.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <daq_api.h>
#include <sfbpf_dlt.h>

#define DAQ_EXAMPLE_VERSION 1

static int example_daq_initialize(const DAQ_Config_t * config, void **ctxt_ptr, char *errbuf, size_t len)
{
    return DAQ_SUCCESS;
}

static int example_daq_set_filter(void *handle, const char *filter)
{
    return DAQ_SUCCESS;
}

static int example_daq_start(void *handle)
{
    return DAQ_SUCCESS;
}

static int example_daq_acquire(void *handle, int cnt, DAQ_Analysis_Func_t callback, void *user)
{
    return DAQ_SUCCESS;
}

static int example_daq_inject(void *handle, const DAQ_PktHdr_t * hdr, const uint8_t * packet_data,
                              uint32_t len, int reverse)
{
    return DAQ_SUCCESS;
}

static int example_daq_breakloop(void *handle)
{
    return DAQ_SUCCESS;
}

static int example_daq_stop(void *handle)
{
    return DAQ_SUCCESS;
}

static void example_daq_shutdown(void *handle)
{
}

static DAQ_State example_daq_check_status(void *handle)
{
	return DAQ_STATE_UNINITIALIZED;
}

static int example_daq_get_stats(void *handle, DAQ_Stats_t * stats)
{
    return DAQ_SUCCESS;
}

static void example_daq_reset_stats(void *handle)
{
}

static int example_daq_get_snaplen(void *handle)
{
    return 0;
}

static uint32_t example_daq_get_capabilities(void *handle)
{
    return DAQ_CAPA_NONE;
}

static int example_daq_get_datalink_type(void *handle)
{
    return DLT_EN10MB;
}

static const char *example_daq_get_errbuf(void *handle)
{
    return NULL;
}

static void example_daq_set_errbuf(void *handle, const char *string)
{
}

static int example_daq_get_device_index(void *handle, const char *device)
{
    return DAQ_ERROR_NOTSUP;
}

#ifdef BUILDING_SO
SO_PUBLIC const DAQ_Module_t DAQ_MODULE_DATA =
#else
const DAQ_Module_t example_daq_module_data =
#endif
{
    .api_version = DAQ_API_VERSION,
    .module_version = DAQ_EXAMPLE_VERSION,
    .name = "example",
    .type = DAQ_TYPE_INLINE_CAPABLE | DAQ_TYPE_INTF_CAPABLE | DAQ_TYPE_MULTI_INSTANCE,
    .initialize = example_daq_initialize,
    .set_filter = example_daq_set_filter,
    .start = example_daq_start,
    .acquire = example_daq_acquire,
    .inject = example_daq_inject,
    .breakloop = example_daq_breakloop,
    .stop = example_daq_stop,
    .shutdown = example_daq_shutdown,
    .check_status = example_daq_check_status,
    .get_stats = example_daq_get_stats,
    .reset_stats = example_daq_reset_stats,
    .get_snaplen = example_daq_get_snaplen,
    .get_capabilities = example_daq_get_capabilities,
    .get_datalink_type = example_daq_get_datalink_type,
    .get_errbuf = example_daq_get_errbuf,
    .set_errbuf = example_daq_set_errbuf,
    .get_device_index = example_daq_get_device_index
};
